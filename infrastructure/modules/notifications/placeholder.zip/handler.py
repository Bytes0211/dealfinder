# placeholder — replaced by CI/CD
def handler(event, context): return {}